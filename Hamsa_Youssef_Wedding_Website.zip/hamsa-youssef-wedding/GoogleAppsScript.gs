/**
 * Wedding RSVP + wishes backend. Deploy as Web App, Execute as: Me,
 * Who has access: Anyone. Set SPREADSHEET_ID before deployment.
 * Never put this file or the spreadsheet ID into a public GitHub repo if privacy matters.
 */
const SPREADSHEET_ID = 'PASTE_YOUR_GOOGLE_SHEET_ID_HERE';
const RSVP_SHEET = 'RSVP';
const WISHES_SHEET = 'Wishes';
const MAX_SIGNATURE_LENGTH = 180000;

function getSheet_(name, headers) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  let sh = ss.getSheetByName(name);
  if (!sh) { sh = ss.insertSheet(name); sh.appendRow(headers); sh.setFrozenRows(1); }
  return sh;
}
function json_(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}
function clean_(value, max) {
  // Prevent spreadsheet formula injection and strip control chars.
  let s = String(value == null ? '' : value).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0,max);
  if (/^[=+\-@]/.test(s)) s = "'" + s;
  return s;
}
function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const d = JSON.parse((e.postData && e.postData.contents) || '{}');
    const name = clean_(d.name,100);
    if (!name) return json_({ok:false,error:'Name is required.'});
    lock.waitLock(10000);
    if (d.type === 'rsvp') {
      const phone = clean_(d.phone,30);
      const attendance = d.attendance === 'Yes' ? 'Yes' : d.attendance === 'No' ? 'No' : '';
      const guests = attendance === 'No' ? 0 : Number(d.guests);
      if (!phone || !attendance || !Number.isInteger(guests) || guests < 0 || guests > 4 || (attendance === 'Yes' && guests < 1)) return json_({ok:false,error:'Invalid RSVP details.'});
      getSheet_(RSVP_SHEET,['Timestamp','Name','Phone','Attending','Guest count']).appendRow([new Date(),name,phone,attendance,guests]);
      return json_({ok:true});
    }
    if (d.type === 'wish') {
      const message = clean_(d.message,700);
      if (!message) return json_({ok:false,error:'Message is required.'});
      const signature = String(d.signature || '');
      if (signature.length > MAX_SIGNATURE_LENGTH || (signature && !/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(signature))) return json_({ok:false,error:'Signature is too large or invalid.'});
      // The signature is stored as a data URI in the private Sheet. Do not publish this Sheet.
      getSheet_(WISHES_SHEET,['Timestamp','Name','Message','Public','Signature PNG data URL']).appendRow([new Date(),name,message,d.public===true?'Yes':'No',signature]);
      return json_({ok:true});
    }
    return json_({ok:false,error:'Unknown submission type.'});
  } catch(err) { return json_({ok:false,error:'Server error. Please try again.'}); }
  finally { try {lock.releaseLock()}catch(e){} }
}
function doGet(e) {
  try {
    if (!e.parameter || e.parameter.action !== 'wishes') return json_({ok:false,error:'Unknown action.'});
    const sh=getSheet_(WISHES_SHEET,['Timestamp','Name','Message','Public','Signature PNG data URL']);
    const n=sh.getLastRow();
    if (n<2) return json_({ok:true,wishes:[]});
    const values=sh.getRange(Math.max(2,n-99),1,Math.min(98,n-1),4).getValues();
    const wishes=values.filter(r=>r[3]==='Yes').reverse().slice(0,20).map(r=>({name:String(r[1]),message:String(r[2])}));
    return json_({ok:true,wishes:wishes});
  }catch(err){return json_({ok:false,error:'Could not load wishes.'});}
}
